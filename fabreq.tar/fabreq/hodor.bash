fabreq.hodor () 
{ 
    while true; do
        echo -n .;
        sleep 10;
    done
}
