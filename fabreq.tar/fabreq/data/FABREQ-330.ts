Script started on Thu 25 Jan 2018 07:36:28 PM CST
[32mwelcome to the shell..
bash: 26498: No such file or directory
[36m[?1034hbash-4.2$ echo z4[K[KQ$[K[K$PPID
26498
bash-4.2$ exit
exit

Script done on Thu 25 Jan 2018 07:36:53 PM CST
Script started on Thu 25 Jan 2018 07:40:32 PM CST
[32mwelcome to the shell..
bash: 26516: No such file or directory
[36m[?1034hbash-4.2$ echo $PPID
26516
bash-4.2$ ps -ef | grep 26516
jrigler  26516 26514  0 19:40 pts/2    00:00:00 script --flush --force --append -c bash -rcfile ~/softball/fabreq/_script.rc /home/jrigler/softball/data/FABREQ-330.ts
jrigler  26517 26516  0 19:40 pts/3    00:00:00 bash -rcfile /home/jrigler/softball/fabreq/_script.rc
jrigler  26519 26517  0 19:40 pts/3    00:00:00 grep 26516
bash-4.2$ [Kbash-4.2$ [Kbash-4.2$ [Kbash-4.2$ [Kbash-4.2$ [Kbash-4.2$ [Kbash-4.2$ [Kbash-4.2$ [Kbash-4.2$ [Kbash-4.2$ [Kbash-4.2$ [Kbash-4.2$ 
Display all 1507 possibilities? (y or n)
bash-4.2$ k[Kset -o vi
bash-4.2$ set -o vips -ef | grep 26516[C[C[C[C[C[C[C[C[C[C[C[C[C[C[C[C[C[C[C[C[C[C[C[C[C[1P516[1P16[1P6[K[K[C $ P P O D = = [1P [1P [1P [1P I S [1P D 
jrigler  26516 26514  0 19:40 pts/2    00:00:00 script --flush --force --append -c bash -rcfile ~/softball/fabreq/_script.rc /home/jrigler/softball/data/FABREQ-330.ts
jrigler  26517 26516  0 19:40 pts/3    00:00:00 bash -rcfile /home/jrigler/softball/fabreq/_script.rc
jrigler  26522 26517  0 19:41 pts/3    00:00:00 grep 26516
bash-4.2$ echo $PPID
26516
bash-4.2$ cat 26514
cat: 26514: No such file or directory
bash-4.2$ pwd
/home/jrigler/softball/fabreq
bash-4.2$ ls
26273  color.bash  define.bash	edit.bash  env.bash  script.bash  _script.rc
bash-4.2$ cat 25[K6273 
hello()
{
echo "hello"
}
hello
bash-4.2$ ps -ef | grep 26273
jrigler  26273 26272  0 19:27 pts/2    00:00:00 -bash
jrigler  26514 26273  0 19:40 pts/2    00:00:00 script --flush --force --append -c bash -rcfile ~/softball/fabreq/_script.rc /home/jrigler/softball/data/FABREQ-330.ts
jrigler  26529 26517  0 19:43 pts/3    00:00:00 grep 26273
bash-4.2$ cat 25[K6273
hello()
{
echo "hello"
}
hello
bash-4.2$ 
bash-4.2$ e[Kls
26273  color.bash  define.bash	edit.bash  env.bash  script.bash  _script.rc
bash-4.2$ echo "00"[K[K[K[K[K[K[K[K[Kwhile true
> do
> echo [K -n .
> ec[K[Ksleep 5
> done
............................................................... ...............................................................................................^C
bash-4.2$ echo $PID[K[KPID
26516
bash-4.2$ ps -ef | grep softball
jrigler  26514 26273  0 19:40 pts/2    00:00:00 script --flush --force --append -c bash -rcfile ~/softball/fabreq/_script.rc /home/jrigler/softball/data/FABREQ-330.ts
jrigler  26516 26514  0 19:40 pts/2    00:00:00 script --flush --force --append -c bash -rcfile ~/softball/fabreq/_script.rc /home/jrigler/softball/data/FABREQ-330.ts
jrigler  26517 26516  0 19:40 pts/3    00:00:00 bash -rcfile /home/jrigler/softball/fabreq/_script.rc
jrigler  27007 26517  0 19:59 pts/3    00:00:00 grep softball
bash-4.2$ exit
exit

Script done on Thu 25 Jan 2018 07:59:29 PM CST
Script started on Thu 25 Jan 2018 08:03:19 PM CST
[32mwelcome to the shell..
bash: 27042: No such file or directory
[36m[?1034hbash-4.2$ ps =e[K[K-ef | grep soft[K[K[K[Kfabreq
jrigler  27040 26273  0 20:03 pts/2    00:00:00 script --flush --force --append -c bash -rcfile ~/softball/fabreq/_script.rc /home/jrigler/softball/data/FABREQ-330.ts
jrigler  27042 27040  0 20:03 pts/2    00:00:00 script --flush --force --append -c bash -rcfile ~/softball/fabreq/_script.rc /home/jrigler/softball/data/FABREQ-330.ts
jrigler  27043 27042  0 20:03 pts/3    00:00:00 bash -rcfile /home/jrigler/softball/fabreq/_script.rc
jrigler  27045 27043  0 20:03 pts/3    00:00:00 grep fabreq
bash-4.2$ exit
exit

Script done on Thu 25 Jan 2018 08:04:00 PM CST
Script started on Thu 25 Jan 2018 08:04:52 PM CST
[32mwelcome to the shell..
bash: 27051: No such file or directory
[36m[?1034hbash-4.2$ ps -ef | grep faab[K[Kbreq
jrigler  27049 26273  0 20:04 pts/2    00:00:00 script --flush --force --append -c bash -rcfile ~/softball/fabreq/_script.rc # 26273 /home/jrigler/softball/data/FABREQ-330.ts
jrigler  27051 27049  0 20:04 pts/2    00:00:00 script --flush --force --append -c bash -rcfile ~/softball/fabreq/_script.rc # 26273 /home/jrigler/softball/data/FABREQ-330.ts
jrigler  27052 27051  0 20:04 pts/3    00:00:00 bash -rcfile /home/jrigler/softball/fabreq/_script.rc
jrigler  27054 27052  0 20:05 pts/3    00:00:00 grep fabreq
bash-4.2$ exit
exit

Script done on Thu 25 Jan 2018 08:05:33 PM CST
Script started on Thu 25 Jan 2018 08:06:25 PM CST
[32mwelcome to the shell..
jrigler  27059 26273  0 20:06 pts/2    00:00:00 script --flush --force --append -c bash -rcfile ~/softball/fabreq/_script.rc # 26273 /home/jrigler/softball/data/FABREQ-330.ts
jrigler  27061 27059  0 20:06 pts/2    00:00:00 script --flush --force --append -c bash -rcfile ~/softball/fabreq/_script.rc # 26273 /home/jrigler/softball/data/FABREQ-330.ts
jrigler  27062 27061  0 20:06 pts/3    00:00:00 bash -rcfile /home/jrigler/softball/fabreq/_script.rc
jrigler  27064 27062  0 20:06 pts/3    00:00:00 grep fabreq
[36m[?1034hbash-4.2$ exit
exit

Script done on Thu 25 Jan 2018 08:06:39 PM CST
Script started on Thu 25 Jan 2018 08:14:17 PM CST
[32mwelcome to the shell..
jrigler  27270 27078  0 20:14 pts/2    00:00:00 script --flush --force --append -c bash -rcfile ~/softball/fabreq/_script.rc # 27078 /home/jrigler/softball/data/FABREQ-330.ts
jrigler  27272 27270  0 20:14 pts/2    00:00:00 script --flush --force --append -c bash -rcfile ~/softball/fabreq/_script.rc # 27078 /home/jrigler/softball/data/FABREQ-330.ts
jrigler  27275 27273  0 20:14 pts/3    00:00:00 grep FABREQ
[36m[?1034hbash-4.2$ exit
exit

Script done on Thu 25 Jan 2018 08:14:54 PM CST
Script started on Thu 25 Jan 2018 08:20:22 PM CST
[32mwelcome to the shell..
jrigler  27490 27078  0 20:20 pts/2    00:00:00 script --flush --force --append -c bash -rcfile ~/softball/fabreq/_script.rc # 27078 /home/jrigler/softball/data/FABREQ-330.ts
jrigler  27492 27490  0 20:20 pts/2    00:00:00 script --flush --force --append -c bash -rcfile ~/softball/fabreq/_script.rc # 27078 /home/jrigler/softball/data/FABREQ-330.ts
jrigler  27495 27493  0 20:20 pts/4    00:00:00 grep FABREQ
[36m[?1034hbash-4.2$ Script started on Thu 25 Jan 2018 08:33:18 PM CST
[32mwelcome to the shell..
jrigler  28235 28039  0 20:33 pts/3    00:00:00 script --flush --force --append -c bash -rcfile ~/softball/fabreq/_script.rc # 28039 /home/jrigler/softball/data/FABREQ-330.ts
jrigler  28237 28235  0 20:33 pts/3    00:00:00 script --flush --force --append -c bash -rcfile ~/softball/fabreq/_script.rc # 28039 /home/jrigler/softball/data/FABREQ-330.ts
jrigler  28240 28238  0 20:33 pts/4    00:00:00 grep FABREQ
[36m[?1034hbash-4.2$ fabreq.
fabreq.color     fabreq.grabname  fabreq.hodor     
bash-4.2$ fabreq.grabname
bash: /home/jrigler/softball/fabreq/FABREQ-330.ts.init: No such file or directory
bash-4.2$ exit
exit

Script done on Thu 25 Jan 2018 08:34:12 PM CST
Script started on Thu 25 Jan 2018 08:34:18 PM CST
[32mwelcome to the shell..
jrigler  28248 28039  0 20:34 pts/3    00:00:00 script --flush --force --append -c bash -rcfile ~/softball/fabreq/_script.rc # 28039 /home/jrigler/softball/data/FABREQ-330.ts
jrigler  28250 28248  0 20:34 pts/3    00:00:00 script --flush --force --append -c bash -rcfile ~/softball/fabreq/_script.rc # 28039 /home/jrigler/softball/data/FABREQ-330.ts
jrigler  28253 28251  0 20:34 pts/4    00:00:00 grep FABREQ
[36m[?1034hbash-4.2$ fabreq.grabname 
bash: /home/jrigler/softball/fabreq/FABREQ-330.init: No such file or directory
bash-4.2$ fabreq.grabname 
bash: /home/jrigler/softball/fabreq/FABREQ-330.init: No such file or directory
bash-4.2$ k[Kset -o vi
bash-4.2$ set -o vifabreq.grabname [C[C[C[C[C[C[C[C[C[C
bash-4.2$ issue 
dadfasadfsadfasdf
bash-4.2$ hori[K[K[K[Kfabvreq.[K[K[K[K[Kreq.hodor
....................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................