fabreq.date.YWw () 
{ 
    date "+%Y%W%w"
}
