fabreq.env () { env | grep _FABREQ ; }
