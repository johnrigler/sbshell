fabreq.date.HM () 
{ 
    date "+%H%M"
}
