fabreq.script () 
{   

#_FABREQ_DIR=/home/jrigler/softball/fabreq
#_FABREQ_DATA=/home/jrigler/softball/fabreq/data/FABREQ-57.ts
#_FABREQ_SHELL=/home/jrigler/softball/fabreq/_script.rc
#_FABREQ_INIT=/home/jrigler/softball/fabreq/init/FABREQ-57.init

    cat $_FABREQ_SHELL $_FABREQ_INIT > $$
    echo >> $$
    echo "fabreq.info" >> $$
    OPTS="--flush --force --append"
    script $OPTS -c "bash -rcfile $$ " $_FABREQ_DATA
    rm $$
    fabreq.color white
}
