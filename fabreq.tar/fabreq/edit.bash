fabreq.edit() {

vi $_FABREQ_DATA

}
