<html>
<pre>










<h1>Unix Hardening Audit</h1>
<hr>
<h2>
<? 
$today = getdate();
echo "$today[month] $today[mday],$today[year]" 
?>
</h2>

<?
echo "<br>Host Set: $argv[1]";
echo "<br>Control Set: $argv[2]";
?>
<hr>

</pre>

</html>
